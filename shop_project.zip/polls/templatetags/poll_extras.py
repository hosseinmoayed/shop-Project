from django import template
from django.http import HttpResponse
from jalali_date import datetime2jalali , date2jalali

register = template.Library()


# @register.filter(name= "show_goorkan")
# def show(value):
#     return value + "goorkan"
#
# @register.filter(name= "check")
# def check(value):
#

@register.filter(name="splitletter")
def Splitletter(value: int):
    return "{:,}".format(value) +" "+ 'تومان'