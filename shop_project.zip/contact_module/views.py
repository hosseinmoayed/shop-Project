import home_module.urls
from django.shortcuts import render, redirect
from django.views import View
from django.views.generic import FormView, CreateView, ListView

# from .forms import CantactUSForm
# Create your views here.
from django.urls import reverse

from site_module.models import SiteSetting
from .forms import ContactUsFormModel
from .models import ContactUs, Uploaded


class ContactUsView(CreateView):
    template_name = "contact_module/contact-us.html"
    form_class = ContactUsFormModel
    success_url = "/"

    def get_context_data(self, *args,**kwargs):
        context = super(ContactUsView, self).get_context_data(*args , *kwargs)
        setting = SiteSetting.objects.filter(is_main_setting=True).first()
        context["setting"] = setting
        return context



# class CreateProfileView(CreateView):
#     template_name = "contact_module/uploadfile.html"
#     model = Uploaded
#     fields = ['image']
#     success_url = "/contact-us/profile"
    # def get(self , request):
    #     form = ProfileForm()
    #     return render(request , "contact_module/uploadfile.html" , context={
    #         'form' : form
    #     })
    #
    # def post(self , request):
    #     submitted_form = ProfileForm(request.POST , request.FILES)
    #     if submitted_form.is_valid():
    #         profile = Uploaded(image=request.FILES["user_image"])
    #         profile.save()
    #         return redirect("/contact-us/profile")
    #     return render(request, "contact_module/uploadfile.html", context={
    #         'form': submitted_form
    #     })









    # def get(self , request):
    #     contactusform = ContactUsFormModel()
    #     return render(request, 'contact_module/contact-us.html', context={
    #         'contactusform': contactusform
    #     })
    # def post(self , request):
    #     contactusform = ContactUsFormModel(request.POST)
    #     if contactusform.is_valid():
    #         contactusform.save()
    #         return redirect(reverse("home_page"))
    #
    #     else:
    #         return render(request, 'contact_module/contact-us.html', context={
    #             'contactusform': contactusform
    #         })


# def contact_us_page(request):
#     if request.method == "POST":
#         # contactusform = CantactUSForm(request.POST)
#         contactusform = ContactUsFormModel(request.POST)
#         if contactusform.is_valid():
#             # contact_model = ContactUs(
#             #     full_name=contactusform.cleaned_data["name"],
#             #     email=contactusform.cleaned_data["email"],
#             #     subject=contactusform.cleaned_data["subject"],
#             #     message=contactusform.cleaned_data["text"]
#             #
#             # )
#             # contact_model.save()
#             contactusform.save()
#             return redirect(reverse("home_page"))
#
#     else:
#         contactusform = ContactUsFormModel()
#     return render(request , 'contact_module/contact-us.html' , context= {
#         'contactusform' : contactusform
#     })



